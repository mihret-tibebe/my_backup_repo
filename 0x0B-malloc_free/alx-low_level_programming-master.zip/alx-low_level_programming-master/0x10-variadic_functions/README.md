# 0x01. C - Variadic functions
C practices on Variadic functiosn
