#0x00.C - Hello, World

This is week once exercise on c
