#include <stdio.h>
/**
 * main - Prints string
 * Description: Prints "\"Programming is like building a multilingual puzzle"
 * Return: 0
 */
int main(void)
{
	puts("\"Programming is like building a multilingual puzzle");
	return (0);
}
