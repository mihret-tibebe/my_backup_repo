# 0x0B. C - malloc, free
Practicing malloc with c
