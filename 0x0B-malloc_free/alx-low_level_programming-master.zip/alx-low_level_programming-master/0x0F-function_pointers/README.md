# 0x0F. C - Function pointers
Function pointer in c
