**0x06-pointers annd strings**
Exercises on pointers and strings
