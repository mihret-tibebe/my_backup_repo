**0x01. C - Variables, if, else, while**

This directory holds all the c practice tests done to understand Variables, if, else, while in c.
