# 0x15. C - File I/O
File manipulation with c
