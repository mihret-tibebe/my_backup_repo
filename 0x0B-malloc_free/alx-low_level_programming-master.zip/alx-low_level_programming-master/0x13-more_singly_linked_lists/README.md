# 0x13. C - More singly linked lists
More linked list exercise with c
