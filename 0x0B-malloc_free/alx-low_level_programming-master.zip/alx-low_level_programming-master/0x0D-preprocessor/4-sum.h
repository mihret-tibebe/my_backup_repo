#ifndef SUM_H
#define SUM_H

#define SUM(x, y) ((x) + (y))
typedef int make_iso_compilers_happy;

#endif
