#include <stdio.h>

/**
 *main - pritns the name of the program
 *Return: 0 on sucess
 */
int main(void)
{
	printf("%s\n", __FILE__);
	return (0);
}
