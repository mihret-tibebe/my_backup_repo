#include "holberton.h"

/**
 * m - a
 */
m{p(); }
