#ifndef PI_H
#define PI_H

#define PI 3.14159265359
typedef int make_iso_compilers_happy;

#endif
