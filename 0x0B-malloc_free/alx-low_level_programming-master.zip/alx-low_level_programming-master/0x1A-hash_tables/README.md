# 0x19. C - Hash tables

In this repository there are exercises written in c, inorder
to understand the wroking of data structures like Hash tables

## Tasks
