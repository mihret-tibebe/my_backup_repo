**0x05-pointers_arrays_strings**
In this directory exercises done on pointers for the alx program
