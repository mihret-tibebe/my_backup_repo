# 0x06. C - Even more pointers, arrays and strings
More exercise on ppointers and strings
