# 0x0A. C - argc, argv
command line argument exercise on c
