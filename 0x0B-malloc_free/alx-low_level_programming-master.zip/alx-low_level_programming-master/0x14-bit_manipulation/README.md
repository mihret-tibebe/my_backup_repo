# 0x14. C - Bit manipulation
Bit manipulation exercise with c
