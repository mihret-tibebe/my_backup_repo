# 0x03. C - Debugging

## Description
This directory hold all the practice tests made on debugginas part of the alx-program
