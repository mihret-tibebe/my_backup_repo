#include "holberton.h"

/**
 * _isupper - checks if input is an uppercase letter in ASCII
 * @c: integer to check
 * Return: 1 if true, 0 if false
 */
int _isupper(int c)
{
	return (c >= 65 && c <= 90);
}
