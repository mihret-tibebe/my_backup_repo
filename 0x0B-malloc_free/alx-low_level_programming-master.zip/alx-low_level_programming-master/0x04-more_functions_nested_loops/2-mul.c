#include "holberton.h"

/**
 * mul - returns product of a & b
 * @a: first integer
 * @b: second integer
 * Return: product of a & b
 */
int mul(int a, int b)
{
	return (a * b);
}
