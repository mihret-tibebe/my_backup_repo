# 0x16. C - Doubly linked lists
Double linked list implimentation with c
