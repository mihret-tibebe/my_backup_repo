# 0x12. C - Singly linked lists
Linked list exercuse with C
