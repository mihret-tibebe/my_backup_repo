# 0x0C. C - More malloc, free
More malloc exercise in c
