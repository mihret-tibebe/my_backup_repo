# Search algorithms

In this exercise, i have practiced different search algorithms using C.

