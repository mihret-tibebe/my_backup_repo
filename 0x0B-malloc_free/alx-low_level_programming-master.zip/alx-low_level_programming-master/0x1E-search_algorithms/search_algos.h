#ifndef SEARCHALGO
#define SEARCHALGO

#include <stdio.h>


int linear_search(int *, size_t, int);
int binary_search(int *, size_t, int);


#endif /*SEARCHALGO*/
