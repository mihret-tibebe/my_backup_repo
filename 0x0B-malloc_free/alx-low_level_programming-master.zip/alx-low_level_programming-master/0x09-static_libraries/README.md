# 0x08. C - Static libraries
Static liberaries in c
