#include "holberton.h"
/**
*add-adds to numbers i and j
*@i:number 1
*@j:bumber 2
*Return: returns i + j
*/
int add(int i, int j)
{
	return (i + j);
}

