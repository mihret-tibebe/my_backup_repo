**0x02-functions_nested_nested_loops**

This subdirectory hold the practice projects done as part of the c programing language practice
