# 0x0E. C - Structures, typedef
structure and typdef exercise in c
